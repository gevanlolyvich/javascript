//username : m._reza_gevan_lolyvich_KI8c
/* Goal tahun ini:
1. Belajar JavaScript.
2. Menjadi Front-End atau Back-End Developer. */